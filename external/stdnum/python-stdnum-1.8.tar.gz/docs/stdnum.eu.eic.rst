stdnum.eu.eic
=============

.. automodule:: stdnum.eu.eic
   :members: