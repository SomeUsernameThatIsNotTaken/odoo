stdnum.es.nie
=============

.. automodule:: stdnum.es.nie
   :members:
