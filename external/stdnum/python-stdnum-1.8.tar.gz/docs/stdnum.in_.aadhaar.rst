stdnum.in\_.aadhaar
===================

.. automodule:: stdnum.in_.aadhaar
   :members: