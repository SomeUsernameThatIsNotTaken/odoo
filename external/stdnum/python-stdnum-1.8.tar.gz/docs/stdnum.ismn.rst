stdnum.ismn
===========

.. automodule:: stdnum.ismn
   :members:
