stdnum.fr.nif
=============

.. automodule:: stdnum.fr.nif
   :members: