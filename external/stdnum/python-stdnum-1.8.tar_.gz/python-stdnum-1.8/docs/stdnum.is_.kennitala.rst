stdnum.is\_.kennitala
=====================

.. automodule:: stdnum.is_.kennitala
   :members: