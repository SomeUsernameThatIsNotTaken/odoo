stdnum.iso7064
==============

.. automodule:: stdnum.iso7064
   :members:

Mod 11, 10
----------
:mod:`stdnum.iso7064.mod_11_10`

.. automodule:: stdnum.iso7064.mod_11_10
   :members:

Mod 11, 2
---------
:mod:`stdnum.iso7064.mod_11_2`

.. automodule:: stdnum.iso7064.mod_11_2
   :members:

Mod 37, 2 (Mod x, 2)
--------------------
:mod:`stdnum.iso7064.mod_37_2`

.. automodule:: stdnum.iso7064.mod_37_2
   :members:

Mod 37, 36 (Mod x+1, x)
-----------------------
:mod:`stdnum.iso7064.mod_37_36`

.. automodule:: stdnum.iso7064.mod_37_36
   :members:

Mod 97, 10
----------
:mod:`stdnum.iso7064.mod_97_10`

.. automodule:: stdnum.iso7064.mod_97_10
   :members:
