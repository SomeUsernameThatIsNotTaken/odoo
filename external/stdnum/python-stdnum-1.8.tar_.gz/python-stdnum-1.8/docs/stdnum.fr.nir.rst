stdnum.fr.nir
=============

.. automodule:: stdnum.fr.nir
   :members: