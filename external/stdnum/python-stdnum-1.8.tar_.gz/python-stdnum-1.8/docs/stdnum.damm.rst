stdnum.damm
===========

.. automodule:: stdnum.damm
   :members: