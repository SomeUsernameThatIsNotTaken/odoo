stdnum.fr.siret
===============

.. automodule:: stdnum.fr.siret
   :members: