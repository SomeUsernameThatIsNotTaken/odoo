stdnum.dk.cpr
=============

.. automodule:: stdnum.dk.cpr
   :members:
