stdnum.bic
==========

.. automodule:: stdnum.bic
   :members: