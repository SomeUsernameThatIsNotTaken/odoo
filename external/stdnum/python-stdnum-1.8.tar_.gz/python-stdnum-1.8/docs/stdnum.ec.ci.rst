stdnum.ec.ci
============

.. automodule:: stdnum.ec.ci
   :members:
