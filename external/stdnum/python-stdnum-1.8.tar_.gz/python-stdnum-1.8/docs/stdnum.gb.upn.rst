stdnum.gb.upn
=============

.. automodule:: stdnum.gb.upn
   :members: