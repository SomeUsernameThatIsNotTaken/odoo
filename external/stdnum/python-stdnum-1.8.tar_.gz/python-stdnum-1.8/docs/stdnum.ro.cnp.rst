stdnum.ro.cnp
=============

.. automodule:: stdnum.ro.cnp
   :members:
